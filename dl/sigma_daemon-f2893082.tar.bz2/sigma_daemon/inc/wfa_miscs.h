/****************************************************************************
 *
 * Copyright (c) 2016 Wi-Fi Alliance
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
 * SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
 * RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT,
 * NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE
 * USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 *****************************************************************************/

#ifndef _WFA_MISCS_H_
#define _WFA_MISCS_H_

extern int isString(char *);
extern int isNumber(char *);
extern int isIpV4Addr(char *);
extern int getIPaddr(char *, char *);
extern double wfa_timeval2double(struct timeval *tval);
extern void wfa_double2timeval(struct timeval *tval, double dval);
extern double wfa_ftime_diff(struct timeval *t1, struct timeval *t2);
extern int wfa_itime_diff(struct timeval *t1, struct timeval *t2);
extern void int2BuffBigEndian(int val, char *buf);
extern int bigEndianBuff2Int(char *buff);
extern char *replace_char(char *str, char find, char replace);
extern int getopt(int argc, char *const argv[], const char *optstring);
#endif
