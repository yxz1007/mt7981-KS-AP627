/****************************************************************************
 *
 * Copyright (c) 2014 Wi-Fi Alliance
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
 * SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
 * RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT,
 * NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE
 * USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 *****************************************************************************/

#ifndef WFA_DEBUG_H
#define WFA_DEBUG_H

#define WFA_ERR stderr /* error: can be redefined to a log file */
#define WFA_OUT stdout /* info:  can be redefined to a log file */
#define WFA_WNG stdout /* warning: can be redefined to a log file */

#define WFA_DEBUG_ERR		0x01
#define WFA_DEBUG_WARNING	0x02
#define WFA_DEBUG_INFO		0x04
#define WFA_DEBUG_SUPPLICANT	0x08

#define WFA_DEBUG 1

#define WFA_DEBUG_DEFAULT	WFA_DEBUG_ERR | WFA_DEBUG_WARNING | WFA_DEBUG_INFO

#define DPRINT_ERR(fd, fmt, args...) \
do { \
	if (wfa_defined_debug & WFA_DEBUG_ERR) \
		fprintf(fd, "[%s:%d] " fmt, __func__, __LINE__, ##args); \
} while(0)

#define DPRINT_WARNING(fd, fmt, args...) \
do { \
	if (wfa_defined_debug & WFA_DEBUG_WARNING) \
		fprintf(fd, fmt, ##args); \
} while(0)

#define DPRINT_INFO(fd, fmt, args...) \
do { \
	if (wfa_defined_debug & WFA_DEBUG_INFO) \
		fprintf(fd, fmt, ##args); \
} while(0)

#ifdef MASK_PARTIAL_MACADDR
#define MAC2STR(a) \
	(a)[0], (a)[1], (a)[2], (a)[5], (a)[8], (a)[9], (a)[10], (a)[11], (a)[12], (a)[13], (a)[14], (a)[15], (a)[16]
#define MACSTR "%c%c%c**%c**%c%c%c%c%c%c%c%c%c"
#endif

#endif /* !WFA_DEBUG_H */
